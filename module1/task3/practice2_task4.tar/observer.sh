#!/bin/bash

CONF=observer.conf
LOG=observer.log

while read TASK
do
    [ -z "$TASK" ] && continue

    if ! pgrep -f "$TASK" >/dev/null
    then
        nohup "./$TASK" >/dev/null 2>&1 &
        echo "$(date '+%F %T') restarted $TASK" >> "$LOG"
    fi

done < "$CONF"
