#!/bin/bash

PIPE=/tmp/run/cuckoo.pid
LOG=cuckoo.log

mkdir -p /tmp/run

[ -p "$PIPE" ] || mkfifo "$PIPE"

shutdown() {
    echo "$(date '+%F %T') Shutdown!" >> "$LOG"
    rm -f "$PIPE"
    exit 0
}

trap shutdown SIGTERM

echo "$(date '+%F %T') Startup!" >> "$LOG"

while true
do
    if read line < "$PIPE"
    then
        NAME=$(echo "$line" | cut -d'[' -f1)
        PID=$(echo "$line" | cut -d'[' -f2 | cut -d']' -f1)

        N=$((RANDOM % 9 + 2))

        echo "$(date '+%F %T') $NAME[$PID] $N" >> "$LOG"

        echo "$N" > /tmp/run/$PID.reply
    fi
done
