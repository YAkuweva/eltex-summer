#!/bin/bash

SCRIPT=$(basename "$0")

if [ "$SCRIPT" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

LOG="report_${SCRIPT}.log"
PID=$$

echo "$(date '+%F %T') [$PID] Скрипт запущен" >> "$LOG"

echo "${SCRIPT}[$PID]: how much time do I have?" > /tmp/run/cuckoo.pid

while [ ! -f "/tmp/run/${PID}.reply" ]
do
    sleep 0.2
done

N=$(cat /tmp/run/${PID}.reply)
rm -f /tmp/run/${PID}.reply

sleep "$N"

echo "$(date '+%F %T') [$PID] Скрипт завершился, работал $N секунд." >> "$LOG"
